---
name: Strategic Wealth Dark
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#ffb2b7'
  on-tertiary: '#67001b'
  tertiary-container: '#ff516a'
  on-tertiary-container: '#5b0017'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffdadb'
  tertiary-fixed-dim: '#ffb2b7'
  on-tertiary-fixed: '#40000d'
  on-tertiary-fixed-variant: '#92002a'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-lg:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
  mono-data:
    fontFamily: Geist Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  container-max: 1440px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 32px
---

## Brand & Style

This design system is engineered for a high-stakes financial optimization platform. The brand personality is authoritative, precise, and sophisticated. It targets high-net-worth individuals and professional advisors who require clarity amidst complex data. 

The aesthetic style is **Corporate / Modern** with a focus on **Tonal Layering**. The interface avoids excessive ornamentation to prioritize data density and legibility. It utilizes subtle elevations and high-contrast accents to guide the user's eye toward critical financial insights and action items. The overall emotional response should be one of "controlled power"—feeling both technologically advanced and financially secure.

## Colors

The color palette is optimized for a dark-first environment, reducing eye strain during long analytical sessions while maintaining AAA accessibility for data visualization.

- **Primary (Strategic Blue):** Reserved for primary calls to action, active states, and focus indicators.
- **Success (Growth Emerald):** Used exclusively for positive financial trends, profit indicators, and completed status.
- **Warning (Tax Crimson):** A soft but urgent red used for tax implications, deficits, or critical alerts.
- **Neutral (Midnight Navy):** The foundational scale. The background uses a near-black (#020617) to provide maximum contrast for the Surface (#0f172a) containers.

## Typography

This design system utilizes **Geist** for its mathematical precision and modern technical feel. 

- **Numerical Data:** For tabular data and currency figures, use the `mono-data` variant (Geist Mono) to ensure tabular lining and perfect vertical alignment across rows.
- **Hierarchy:** Headlines use a semi-bold weight with tight letter spacing to feel "locked-in" and professional.
- **Labels:** Use `label-sm` in all-caps for section headers and table headers to provide a structural skeleton to the data-heavy views.

## Layout & Spacing

The layout follows a **Fixed Grid** model on desktop and a **Fluid Grid** model on mobile. 

- **Grid:** Use a 12-column grid for desktop views with 24px gutters. Content should be centered within a 1440px max-width container.
- **Rhythm:** All spacing (padding, margins) must be multiples of 4px. Use `lg` (24px) for internal card padding and `xl` (48px) for vertical section spacing.
- **Adaptation:** On mobile, margins reduce to 16px and the grid collapses to a single column. Complex data tables should utilize horizontal scrolling with the first column (e.g., Asset Name) pinned for context.

## Elevation & Depth

In this dark-mode environment, depth is communicated through **Tonal Layers** rather than heavy shadows.

- **Level 0 (Background):** Deepest layer (#020617). Used for the main canvas.
- **Level 1 (Surface):** Default container color (#0f172a). Used for cards, sidebars, and navigation rails.
- **Level 2 (Overlay):** Elevated surface (#1e293b). Used for hover states, tooltips, and modal dialogues.
- **Outlines:** Use a 1px border (#1e293b) on all Level 1 surfaces to provide crisp definition against the background. For active or focused states, transition the border color to the Strategic Blue primary color.

## Shapes

The design system uses a **Soft** shape language to balance the technical nature of financial data with a premium, approachable feel.

- **Small Elements:** Buttons, inputs, and tags use `rounded` (0.25rem).
- **Large Elements:** Cards and modals use `rounded-lg` (0.5rem).
- **Interactive States:** Maintain consistent radii across all states (hover, active, disabled) to ensure UI stability.

## Components

### Buttons
- **Primary:** Strategic Blue background with white text. No gradient. High-contrast white icon.
- **Secondary:** Transparent background with a 1px border of Strategic Blue.
- **Ghost:** Minimal padding, Strategic Blue text, used for secondary navigation within cards.

### Input Fields
- **Default:** Surface-elevated background with a subtle border (#334155). 
- **Focus:** Border color transitions to Strategic Blue with a 2px outer glow (0% blur) of the same color.
- **Validation:** Use Success Emerald for verified fields and Warning Crimson for tax-critical errors.

### Cards
- Standard containers for data modules. Use 1px border (#1e293b) and `rounded-lg` corners.
- Header area of cards should use `label-sm` for titles to maintain a dashboard aesthetic.

### Data Visualization
- **Trend Lines:** Use 2px stroke width. 
- **Tooltips:** Use the Overlay surface (#1e293b) with 85% opacity and a backdrop-blur (8px) for a premium "glass" feel that doesn't obscure the underlying data completely.

### Lists & Tables
- **Zebra Striping:** Avoid zebra stripes. Instead, use thin horizontal dividers (#1e293b).
- **Hover State:** Apply a subtle background change to #1e293b on row hover to indicate interactivity.